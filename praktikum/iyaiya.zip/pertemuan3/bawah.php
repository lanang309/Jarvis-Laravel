    <footer>
        <p>Created By Mahasiswa <a href="https://elena.nurulfikri.ac.id/" target="_blank"></a> STT NF 2022</p>
    </footer>
</body>
</html>