<?php 
include_once 'atas.php';
?>
<h1>Welcome To MY Blog</h1>
<?php 
require_once 'bawah.php';
?>

