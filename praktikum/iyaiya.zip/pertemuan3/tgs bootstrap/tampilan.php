<?php 
include_once 'atas.php';
?>
<?php 
require_once 'sidebar.php';
?>
<?php 
require_once 'bawah.php';
?>